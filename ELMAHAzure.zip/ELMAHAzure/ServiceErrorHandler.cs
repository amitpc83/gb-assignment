﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ServiceModel.Dispatcher;
using System.ServiceModel;
using System.Data.SqlClient;
using System.ServiceModel.Channels;
using System.ServiceModel.Description;
using System.ServiceModel.Configuration;
using System.Threading;

namespace ELMAHIntegration
{
    public class ServiceErrorHandler : IErrorHandler, IServiceBehavior
    {
        #region IErrorHandler Members

        public bool HandleError(Exception error)
        {
            return true;
        }

        public void ProvideFault(Exception error, System.ServiceModel.Channels.MessageVersion version, ref System.ServiceModel.Channels.Message fault)
        {
            if (error != null && HttpContext.Current != null) // Notify ELMAH of the exception.
            {
                try
                {
                    Elmah.ErrorSignal.FromCurrentContext().Raise(error);
                }
                catch (Exception loggerException)
                {
                    //If failed to log with ELMAH trace it.
                    System.Diagnostics.Trace.TraceError(error.GetDetails());
                    System.Diagnostics.Trace.TraceError(loggerException.GetDetails());
                }
            }
            return;
        }

        #endregion

        #region IServiceBehavior Members

        public void AddBindingParameters(ServiceDescription serviceDescription, ServiceHostBase serviceHostBase, System.Collections.ObjectModel.Collection<ServiceEndpoint> endpoints, BindingParameterCollection bindingParameters)
        {
            return;
        }

        public void ApplyDispatchBehavior(ServiceDescription serviceDescription, ServiceHostBase serviceHostBase)
        {
            foreach (ChannelDispatcher dispatcher in serviceHostBase.ChannelDispatchers)
            {
                dispatcher.ErrorHandlers.Add(this);
            }
        }

        public void Validate(ServiceDescription serviceDescription, ServiceHostBase serviceHostBase)
        {
            //TODO: Validate all contracts for fault contract attribute

            return;
        }

        #endregion
    }


    public class ServiceErrorHandlerExtensionElement : BehaviorExtensionElement
    {

        public override Type BehaviorType
        {
            get { return typeof(ServiceErrorHandler); }
        }

        protected override object CreateBehavior()
        {
            return new ServiceErrorHandler();
        }
    }
}
