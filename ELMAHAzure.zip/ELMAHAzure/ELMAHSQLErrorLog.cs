﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.WindowsAzure.ServiceRuntime;
using System.Configuration;
using System.Collections;

namespace ELMAHIntegration
{
    public class ELMAHSQLErrorLog : Elmah.SqlErrorLog
    {
        // Summary:
        //     Initializes a new instance of the Elmah.SqlErrorLog class using a dictionary
        //     of configured settings.
        public ELMAHSQLErrorLog(IDictionary config):base(config) {}
        //
        // Summary:
        //     Initializes a new instance of the Elmah.SqlErrorLog class to use a specific
        //     connection string for connecting to the database.
        public ELMAHSQLErrorLog(string connectionString):base(connectionString) { }


        private const string ErrorLoggerConnectionStringConfigKey = "ErrorLoggerConnectionString";
		/// <summary>
        /// Overrides the connectionstring value with value retieved from Azure configuration in case application is running in Azure
        /// </summary>
        /// <value>The connection string.</value>
        public override string ConnectionString
        {
            get
            {
                if (RoleEnvironment.IsAvailable)
                {
                    return RoleEnvironment.GetConfigurationSettingValue(ErrorLoggerConnectionStringConfigKey);
                }
                else
                {
                    return ConfigurationManager.ConnectionStrings[ErrorLoggerConnectionStringConfigKey].ConnectionString;
                }

            }
        }
    }
}