﻿namespace quiz_backend.Models
{
    public class Quiz
    {
        public int ID { get; set; }
        public string Title { get; set; }
    }
}
