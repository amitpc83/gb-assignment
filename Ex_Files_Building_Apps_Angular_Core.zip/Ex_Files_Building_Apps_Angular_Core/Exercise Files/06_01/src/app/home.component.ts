import { Component } from '@angular/core'

@Component({
  template: '<question></question><questions><questions>'
})
export class HomeComponent {
}
