import { Component } from '@angular/core'

@Component({
    selector: 'question',
    template:'this is my question component'
})
export class QuestionComponent {

}