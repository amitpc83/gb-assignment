import { Component } from '@angular/core'

@Component({
  selector: 'app-root',
  template: '<question></question><questions><questions>'
})
export class AppComponent {
  title = 'my app';
}
